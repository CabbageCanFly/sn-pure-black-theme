# Changelog

Format: `major.minor.patch`

## 1.0.1 (October 30, 2020)

### Updates/Changes

- Flattened colours a bit; revised text selection colour
- Darkened scrollbar

## 1.0.0 (October 29, 2020)

- Slightly increased brightness of black backgrounds
