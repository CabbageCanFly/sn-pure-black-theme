# Changelog

Format: `major.minor.patch`

## 1.0.2 (February 5, 2022)

### Updates/Changes

- Update theme with forked repo for updated Standard Notes design

## 1.0.1 (October 30, 2020)

### Updates/Changes

- Flattened colours a bit; revised text selection colour
- Darkened scrollbar

## 1.0.0 (October 29, 2020)

- Slightly increased brightness of black backgrounds
