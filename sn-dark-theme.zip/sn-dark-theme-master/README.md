# Dark Theme for Standard Notes

Theme for [Standard Notes](https://standardnotes.org/).

## Installation

On the Desktop app or web-version, open "Extensions" in Standard Notes and click "Import Extension". Enter the following URL as Extension Link and press Enter:

```
https://cabbagecanfly.com/sn-dark-theme/sn-dark-theme.zip
```

<!-- ## Preview -->

<!-- <img src="https://raw.githubusercontent.com/christianhans/sn-pure-black-theme/master/preview1.png" width="300px">  <img src="https://raw.githubusercontent.com/christianhans/sn-pure-black-theme/master/preview2.png" width="300px"> -->
